/**
 * Dubiously created by Adrian Cooney
 * http://adriancooney.github.io
 */
(function(console) {
  "use strict";

  //Bootlegged of imgur.com/memegen
  var memes = {
    "10 Guy": "mems/LaENqOV.jpg",
    "3rd World Success Kid": "mems/WA5duA1.jpg",
    "90's Problems": "mems/tL47qtp.jpg",
    "Aaand It's Gone": "mems/yf12saq.jpg",
    "Actual Advice Mallard": "mems/WymFmVy.jpg",
    "Advice Dog": "mems/Qk0VO6D.jpg",
    "Advice God": "mems/xH2fSFg.jpg",
    "Almost Politically Correct Redneck": "mems/YqLgINf.jpg",
    "Am I The Only One": "mems/gS9YL5U.jpg",
    "Ancient Aliens": "mems/NfCknz0.jpg",
    "Annoyed Picard": "mems/s9GmfSS.jpg",
    "Annoying Childhood Friend": "mems/27VCyQw.jpg",
    "Annoying Facebook Girl": "mems/ccczyGt.jpg",
    "Anti-Joke Chicken (Rooster)": "mems/KOsW0jh.jpg",
    "Awkward Penguin": "mems/ez1tQrq.jpg",
    "Back In My Day Grandpa": "mems/zuJSZp8.jpg",
    "Bad Advice Mallard": "mems/QEPvL2B.jpg",
    "Bad Luck Brian": "mems/sRW8BiO.jpg",
    "Bear Grylls": "mems/6Spqy1D.jpg",
    "Brace Yourself": "mems/NhIq0LY.jpg",
    "Captain Obvious": "mems/DmUcxBu.jpg",
    "Chemistry Cat": "mems/8agP4Xe.jpg",
    "College Freshman": "mems/2Ynyv9t.jpg",
    "College Liberal": "mems/OWfvSFE.jpg",
    "Condescending Wonka": "mems/D0e5fgL.jpg",
    "Confession Bear": "mems/kH1SKhp.jpg",
    "Confession Kid": "mems/jhOxR12.jpg",
    "Confused Gandalf": "mems/iIb5SEo.jpg",
    "Conspiracy Keanu": "mems/pFyk3J7.jpg",
    "Courage Wolf": "mems/H5qoXFb.jpg",
    "Dating Site Murderer": "mems/jffNNql.jpg",
    "Depression Dog": "mems/wgad6P8.jpg",
    "Drunk Baby": "mems/QvZdbRE.jpg",
    "English Motherfucker": "mems/sJThEC0.jpg",
    "Evil Plotting Raccoon": "mems/xMslWFf.jpg",
    "First Day On The Internet Kid": "mems/TWfdmVu.jpg",
    "First World Cat Problems": "mems/0vR5Slq.jpg",
    "First World Problem": "mems/ATcIl08.jpg",
    "Forever Alone": "mems/pcfXSUU.jpg",
    "Forever Resentful Mother": "mems/pIrdwo2.jpg",
    "Foul Bachelor Frog": "mems/JUFmusm.jpg",
    "Foul Bachelorette Frog": "mems/dYf971U.jpg",
    "Friendzone Fiona": "mems/Qu1eedL.jpg",
    "Frustrated Farnsworth": "mems/U3SElKP.jpg",
    "Fuck Me, Right?": "mems/J9gfxsx.jpg",
    "Gangster Baby": "mems/C3XhI56.jpg",
    "Good Girl Gina": "mems/qK6lYr2.jpg",
    "Good Guy Greg": "mems/UXMPoKN.jpg",
    "Grandma Finds The Internet": "mems/xPfGYqu.jpg",
    "Grinds My Gears": "mems/t4JqU1j.jpg",
    "Grumpy Cat (Tard)": "mems/dU5CDxN.jpg",
    "High Expectations Asian Father": "mems/7QeB9LI.jpg",
    "Hipster Barista": "mems/AbWxdy2.jpg",
    "Horrifying House Guest": "mems/DxmoFp1.jpg",
    "I Dare You Samuel Jackson": "mems/UQtpdqj.jpg",
    "I Should Buy A Boat": "mems/XqlqPxn.jpg",
    "I Too Like To Live Dangerously": "mems/qF70EL9.jpg",
    "Idiot Nerd Girl": "mems/8hYPYwd.jpg",
    "Insanity Wolf": "mems/GOOdg3k.jpg",
    "Joker Mind Loss": "mems/qQIRaOD.jpg",
    "Joseph Ducreux": "mems/QL7TyR9.jpg",
    "Lame Joke Eel": "mems/oQXw3jF.jpg",
    "Lame Pun Raccoon": "mems/nvALRK3.jpg",
    "Lazy College Senior": "mems/PpkVfzz.jpg",
    "Mad Karma": "mems/G0QMPum.jpg",
    "Masturbating Spidey": "mems/dZ7AB4c.jpg",
    "Matrix Morpheus": "mems/8Yrw6cZ.jpg",
    "Mayonnaise Patrick": "mems/5jE0Y7f.jpg",
    "Musically Oblivious 8th Grader": "mems/l5YHN5D.jpg",
    "Not Sure Fry": "mems/7rFgBB1.jpg",
    "Oblivious Suburban Mom": "mems/Y7o7UJs.jpg",
    "One Does Not Simply": "mems/7LrwR1Y.jpg",
    "Overly Attached Girlfriend": "mems/5blLJLR.jpg",
    "Overly Manly Man": "mems/dOSn9Na.jpg",
    "Paranoid Parrot": "mems/KooYHdg.jpg",
    Pedobear: "mems/c6JZKRW.jpg",
    "Pepperidge Farm Remembers": "mems/uFde4v5.jpg",
    Philosoraptor: "mems/eERhI5h.jpg",
    "Priority Peter": "mems/BBEFk0e.jpg",
    "Rasta Science Teacher": "mems/Js6Ai5T.jpg",
    "Redditor's Wife": "mems/d1XfJeD.jpg",
    "Revenge Band Kid": "mems/dlvmaRI.jpg",
    "Schrute Facts": "mems/UxcvPwT.jpg",
    "Scumbag Brain": "mems/OZhhZdS.jpg",
    "Scumbag Steve": "mems/Rfvoc0Y.jpg",
    "Sexually Oblivious Rhino": "mems/RoaNuEC.jpg",
    "Sheltering Suburban Mom": "mems/vMkSofv.jpg",
    "Shut Up And Take My Money": "mems/uWe0rtQ.jpg",
    "Skeptical Third World Kid": "mems/uwAusxV.jpg",
    "Smug Spongebob": "mems/OTTRjrv.jpg",
    "Socially Awesome Penguin": "mems/S6WgQW7.jpg",
    "Success Kid": "mems/ZibijBz.jpg",
    "Successful Black Man": "mems/ogIm0cy.jpg",
    "Sudden Clarity Clarence": "mems/N3Xmfbe.jpg",
    "Tech Impaired Duck": "mems/riz28ci.jpg",
    "The Most Interesting Man In The World": "mems/MGv15MH.jpg",
    "The Rent Is Too High": "mems/r5WLktQ.jpg",
    "Tough Spongebob": "mems/2w0F1HX.jpg",
    "Unhelpful Highschool Teacher": "mems/ohbGhuD.jpg",
    "Vengeance Dad": "mems/0nUStsa.jpg",
    "What Year Is It?": "mems/fj79hQS.jpg",
    "X, X Everywhere": "mems/GGy94Gt.jpg",
    "Yeah That'd Be Great": "mems/nz9M2pl.jpg",
    "Yo Dawg Xzibit": "mems/XOyGqF2.jpg",
    "You're Bad And You Should Feel Bad": "mems/YsabGnQ.jpg",
    "You're Gonna Have A Bad Time": "mems/2tNR7P7.jpg"
  };

  /**
   * Since the console.log doesn't respond to the `display` style,
   * setting a width and height has no effect. In fact, the only styles
   * I've found it responds to is font-size, background-image and color.
   * To combat the image repeating, we have to get a create a font bounding
   * box so to speak with the unicode box characters. EDIT: See Readme.md
   *
   * @param  {int} width  The height of the box
   * @param  {int} height The width of the box
   * @return {object}     {string, css}
   */
  function getBox(width, height) {
    return {
      string: "+",
      style:
        "font-size: 1px; padding: 0 " +
        Math.floor(width / 2) +
        "px; line-height: " +
        height +
        "px;"
    };
  }

  /**
   * Draw's meme text on a context.
   *
   * @param  {CanvasRenderingContext2D} ctx   The canvas context
   * @param  {string} type  "upper"|"lower"
   * @param  {string} text  The text to draw
   * @param  {int} width The width of the image
   * @param  {int} y     The y value to draw at
   * @return {null}
   */
  function drawMemeText(ctx, type, text, width, y) {
    text = text.toUpperCase();
    //Determine the font size
    if (text.length < 24) {
      var val = Math.max(0, text.length - 12),
        size = 70 + val * -3;

      drawText(ctx, size, text, width / 2, y);
    } else if (text.length < 29) {
      drawText(ctx, 40, text, width / 2, y);
    } else {
      var strs = wrap(text, 27);
      strs.forEach(function(str, i) {
        drawText(
          ctx,
          40,
          str,
          width / 2,
          type == "lower" ? y - (strs.length - 1) * 40 + i * 40 : y + i * 40
        );
      });
    }
  }

  /**
   * Draws text in impact font with stroke on context
   *
   * @param  {CanvasRenderingContext2D} ctx  The canvas context
   * @param  {int} size Font size
   * @param  {string} text The string to write
   * @param  {int} x    X Position
   * @param  {int} y    Y position
   * @return {null}
   */
  function drawText(ctx, size, text, x, y) {
    //Set the text styles
    ctx.font = "bold " + size + "px Impact";
    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineWidth = 7;
    ctx.strokeStyle = "#000";
    ctx.strokeText(text, x, y);
    ctx.fillText(text, x, y);
  }

  /**
   * Wrap a line of text at an index
   *
   * @param  {string} text The text
   * @param  {int} num  The index to wrap at
   * @return {array}      Array of text
   */
  function wrap(text, num) {
    var output = [],
      split = text.split(" ");

    var str = [];
    for (var i = 0, cache = split.length; i < cache; i++) {
      if ((str + split[i]).length < num) str.push(split[i]);
      else {
        output.push(str.join(" "));
        str.length = 0;
        str.push(split[i]);
      }
    }

    //Push the final line
    output.push(str.join(" "));

    return output;
  }

  /**
   * Add a meme to the console!
   *
   * @param  {string} upper  The upper text
   * @param  {string} lower  The lower text
   * @param  {string} image  The meme type (see `console.meme` for all supported) or image url (Make sure it's CORS enabled)
   * @param  {int} width  The width of the meme
   * @param  {int} height The height of the meme
   * @return {null}
   */
  console.meme = function(upper, lower, image, width, height) {
    if (!upper)
      console.error(
        "Yo, you forgot the text for the upper part of the meme. The bit at the top. Yeah, that bit."
      );
    if (!lower)
      console.error("You forgot the text for the bottom of the meme, stupid.");
    if (!image)
      console.error(
        "Dude, you forgot the meme type or url for the background image (CORS enabled, *hint* imgur *hint*). To see a list of supported memes, hit `console.meme()`"
      );
    if (!upper && !lower && !image)
      return console.log("> " + Object.keys(memes).join("\n> "));

    var canvas = document.createElement("canvas"),
      ctx = canvas.getContext("2d"),
      width = width || 500,
      height = width || 500,
      //I tweaked it at these dimensions,
      //So everything scales from here
      _w = 500,
      _h = 500;

    var img = new Image();
    img.setAttribute("crossOrigin", "anonymous");
    img.onload = function() {
      canvas.width = width;
      canvas.height = height;

      var text = upper.toUpperCase();

      ctx.scale(width / 500, height / 500);

      //Draw the background
      ctx.drawImage(this, 0, 0, _w, _h);

      drawMemeText(ctx, "upper", upper, _w, 50); //upper
      drawMemeText(ctx, "lower", lower, _w, _h - 50); //upper

      console.image(canvas.toDataURL());
    };

    if (memes[image]) var url = memes[image];
    else var url = image;

    img.src = url; //"http://www.corsproxy.com/" + url.replace(/https?:\/\//, "");
  };

  /**
   * Display an image in the console.
   * @param  {string} url The url of the image.
   * @param  {int} scale Scale factor on the image
   * @return {null}
   */
  console.image = function(url, scale) {
    scale = scale || 1;
    var img = new Image();

    img.onload = function() {
      var dim = getBox(this.width * scale, this.height * scale);
      console.log(
        "%c" + dim.string,
        dim.style +
          "background: url(" +
          url +
          "); background-size: " +
          this.width * scale +
          "px " +
          this.height * scale +
          "px; color: transparent;"
      );
    };

    img.src = url;
  };
})(console);
